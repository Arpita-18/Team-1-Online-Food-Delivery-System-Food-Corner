import { Injectable } from '@angular/core';
// import { menuData } from '../MenupageComponent.menuData';


@Injectable({
  providedIn: 'root'
})
export class CartService {
  // items: menuData[] = [];

  constructor() { }

  // addToCart(menuData:menuData ){
  // this.items.push(menuData);
  // }

  // getItems(){
  //   return this.items;

  // clearCart(){this.items = [];
  //   return
    
  // }
 }

